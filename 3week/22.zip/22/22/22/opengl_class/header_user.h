#pragma once

//#include "Type.h"
#include "VAO.h"
#include "Buffer.h"
#include "GL.h"
#include "Shader.h"
#include "Figure.h"
#include "Triangle.h"
#include "Rectangle.h"
