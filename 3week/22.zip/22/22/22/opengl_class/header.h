#pragma once
#define _CRT_SECURE_NO_WARNINGS //--- ���α׷� �� �տ� ������ ��
//#include <stdlib.h>
//#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
//#include <cmath>
//#include <array>
#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <gl/glm/glm.hpp>
#include <gl/glm/ext.hpp>
#include <gl/glm/gtc/matrix_transform.hpp>

#define WIDTH 800
#define HEIGHT 600

